# Sansara Systems

AI-assisted dual-role management system for Sansara Condominiums.

Roles:
- Community Association Manager
- Maintenance Supervisor

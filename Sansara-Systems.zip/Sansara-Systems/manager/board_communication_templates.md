## Board Communication Templates

### Monthly Update Email
**To:** Dean Scarborough, Mike Hogan, Kristen Lamb, Kathy Stoute Labauve, Charlotte Bimba  
**Subject:** Monthly Update - Sansara Operations Summary

Dear Board Members,

Here is the monthly update outlining key tasks completed, upcoming responsibilities, and any immediate concerns...

Best regards,  
[Your Name]  
Community Association Manager  

## Monthly Tasks

- Board update report
- Delinquency tracking
- Vendor check-ins
- Maintenance schedule review
## Annual Tasks

- Reserve study review
- Budget planning
- Annual Board Meeting prep
- Vendor contract renewals
- Insurance policy review
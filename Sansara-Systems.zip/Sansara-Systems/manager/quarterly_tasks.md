## Quarterly Tasks

- Financial review and budget comparison
- Fire system inspection scheduling
- Community event planning
- Report delinquency trends
## Daily Maintenance Checklist

- Walk property perimeter
- Inspect pool & amenity areas
- Check trash/recycle rooms
- Report any work order needs
## Inspection Schedule

- Fire Alarm System: Quarterly
- Elevator: Annually
- Sprinkler System: Quarterly
- Backflow Preventer: Annually
- Roof & Exterior: Annually
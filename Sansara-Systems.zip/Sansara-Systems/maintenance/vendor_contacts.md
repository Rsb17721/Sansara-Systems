## Vendor Contacts

| Service | Company | Contact | Phone |
|--------|---------|---------|--------|
| Elevator | [Company Name] | [Name] | [Phone] |
| Plumbing | [Company Name] | [Name] | [Phone] |
| Landscaping | [Company Name] | [Name] | [Phone] |